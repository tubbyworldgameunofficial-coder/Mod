package com.luki.iteminspector.client;

import com.luki.iteminspector.LukiItemInspector;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = LukiItemInspector.MOD_ID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class InspectorClient {
    private static KeyMapping INSPECT;
    private static boolean inspecting;
    private static boolean havePreviousRotation;
    private static float previousPlayerYaw, previousPlayerPitch;
    private static float itemYaw, itemPitch, zoom;
    private static float inspectProgress, previousInspectProgress;

    private InspectorClient() {}

    public static void registerKeys(RegisterKeyMappingsEvent event) {
        INSPECT = new KeyMapping("key.lukiiteminspector.inspect",
                KeyConflictContext.IN_GAME, GLFW.GLFW_KEY_G,
                "key.categories.lukiiteminspector");
        event.register(INSPECT);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        previousInspectProgress = inspectProgress;
        if (mc.player == null || mc.level == null) {
            inspecting = false;
            inspectProgress = 0.0F;
            havePreviousRotation = false;
            return;
        }
        if (INSPECT != null && INSPECT.consumeClick()) {
            if (!mc.player.isSpectator() && !mc.player.isUsingItem() && !mc.player.isPassenger()) {
                inspecting = !inspecting;
                havePreviousRotation = false;
                if (inspecting) itemYaw = itemPitch = zoom = 0.0F;
            }
        }
        float target = inspecting && mc.screen == null ? 1.0F : 0.0F;
        inspectProgress += (target - inspectProgress) * 0.35F;
        if (Math.abs(target - inspectProgress) < 0.002F) inspectProgress = target;
        if (!inspecting || mc.screen != null) {
            inspecting = false;
            havePreviousRotation = false;
            return;
        }
        float currentYaw = mc.player.getYRot();
        float currentPitch = mc.player.getXRot();
        if (havePreviousRotation) {
            itemYaw = wrapDegrees(itemYaw + wrapDegrees(currentYaw - previousPlayerYaw) * 1.7F);
            itemPitch = clamp(itemPitch + (currentPitch - previousPlayerPitch) * 1.7F, -80.0F, 80.0F);
            mc.player.setYRot(previousPlayerYaw);
            mc.player.setXRot(previousPlayerPitch);
        } else {
            havePreviousRotation = true;
        }
        previousPlayerYaw = mc.player.getYRot();
        previousPlayerPitch = mc.player.getXRot();
    }

    @SubscribeEvent
    public static void onMouseScroll(InputEvent.MouseScrollingEvent event) {
        if (!inspecting) return;
        zoom = clamp(zoom + (float) event.getScrollDelta() * 0.045F, -0.30F, 0.42F);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (inspectProgress <= 0.01F) return;
        event.setCanceled(true);
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        Minecraft mc = Minecraft.getInstance();
        if (!(mc.player instanceof AbstractClientPlayer player) || mc.level == null) return;
        PoseStack pose = event.getPoseStack();
        MultiBufferSource buffers = event.getMultiBufferSource();
        int light = event.getPackedLight();
        float partial = event.getPartialTick();
        float progress = previousInspectProgress + (inspectProgress - previousInspectProgress) * partial;
        float eased = progress * progress * (3.0F - 2.0F * progress);
        EntityRenderDispatcher dispatcher = mc.getEntityRenderDispatcher();
        if (dispatcher.getRenderer(player) instanceof PlayerRenderer renderer) {
            pose.pushPose();
            renderer.renderRightHand(pose, buffers, light, player);
            renderer.renderLeftHand(pose, buffers, light, player);
            pose.popPose();
        }
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty()) held = player.getOffhandItem();
        if (held.isEmpty()) return;
        pose.pushPose();
        pose.translate(0.0D, -0.17D * eased, -0.48D - 0.30D * eased + zoom * eased);
        pose.mulPose(com.mojang.math.Axis.XP.rotationDegrees(-8.0F + itemPitch * eased));
        pose.mulPose(com.mojang.math.Axis.YP.rotationDegrees(itemYaw * eased));
        pose.mulPose(com.mojang.math.Axis.ZP.rotationDegrees(7.0F * eased));
        float scale = 1.0F + 0.48F * eased;
        pose.scale(scale, scale, scale);
        mc.getItemRenderer().renderStatic(player, held, ItemDisplayContext.FIXED,
                false, pose, buffers, mc.level, light, OverlayTexture.NO_OVERLAY, player.getId());
        pose.popPose();
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
    private static float wrapDegrees(float value) {
        value %= 360.0F;
        if (value >= 180.0F) value -= 360.0F;
        if (value < -180.0F) value += 360.0F;
        return value;
    }
}
