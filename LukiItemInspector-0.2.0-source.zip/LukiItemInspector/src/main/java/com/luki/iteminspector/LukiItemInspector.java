package com.luki.iteminspector;

import com.luki.iteminspector.client.InspectorClient;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LukiItemInspector.MOD_ID)
public class LukiItemInspector {
    public static final String MOD_ID = "lukiiteminspector";

    public LukiItemInspector() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(InspectorClient::registerKeys);
    }
}
